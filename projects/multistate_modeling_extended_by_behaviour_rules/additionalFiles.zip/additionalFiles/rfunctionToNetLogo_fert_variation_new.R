###############################################################################
###############################################################################
###########                                                         ###########
###########          R-FUNCTION FILE FOR ABM-MIG MODEL              ###########
###########                                                         ###########
###########          Leuchter, M.; Klabunde, A.; Zinn, S.           ###########
###########                    31-03-2016                           ###########
###############################################################################
###############################################################################

##---------------------------------------------------------------------------##
# STRUCTURE/CONTENT OF THE FILE
##---------------------------------------------------------------------------##
# A. READ INPUT DATA
# B. PERFORM MICROSIMULATION
# B.1 Aux functions for Heligman-Pollard model for mortality
# B.2 Produce synthetic life-courses for natives (used in ABM as initial specification of the life courses of the individuals considered)
# B.3 Produce synthetic life-courses for natives (with higher mortality for those who have too little consumption)
# B.4 Produce synthetic life-courses for migrants (used in ABM as initial specification of the life courses of the individuals considered)
# B.5 Produce synthetic life-courses for migrants (with higher mortality for those who have too little consumption)
# C. TRANSFORMING R DATA TO FORMATS THAT NetLogo CAN PROCESS 
# C.1 Crucial function for transforming NetLogo dates to R dates 
# C.2 Function to transform MicSim (R) pop-object into csv file, allows reading pop object as time series in NetLogo
# C.3 Write popforlogo (MicSim results) into a csv file (for NetLogo)
# C.4 Write popforlogo (MicSim results) into a csv file (for NetLogo), initial migrant population
# C.5 Transform initial population (from R, micSim) that NetLogo can process it
# C.6 Transform synthetic population of children (from R, micSim) that NetLogo can process it
# D. FURTHER FUNCTIONS USED BY NETLOGO WHILE RUNNING SIMULATION
# D.1 Generate random day and month for birth date     
# D.2 Function to create for one single individual an `initPop' object for `micSim'
# D.3 Function to transform NetLogo `time object' into ticks (in R: days)
# E. SAMPLING FROM CENSUS
# E.1 Generate random day and month for birth date    
# E.2 Sampling of men and women in Dakar (calibrated to census 1988)  
# E.3 Sampling of men and women in France (calibrated to census 1982)  

##---------------------------------------------------------------------------##
## A. READ INPUT DATA
##---------------------------------------------------------------------------##
setwd("Y:\\02_Abteilung_2\\02_Methoden\\01_MA-Restricted\\SZ\\ANNA") 

# Fertility: Hadwiger model: parameters 
par <- read.table("1st_new.txt", header=T,check.names=FALSE)      # parity 1
par2 <- read.table("2nd_new.txt", header=T,check.names=FALSE)     # parity 2
par3 <- read.table("3rd_new.txt", header=T,check.names=FALSE)     # parity 3+
# Mortality: Heligman-Pollard model: parameters, natives
par_mtt <- read.table("par_mt4.txt", header=T,check.names=FALSE) # men
par_wtt <- read.table("par_wt4.txt", header=T,check.names=FALSE) # women
# Mortality: Heligman-Pollard model: factors, natives
factor_m <- read.table("factor_m.txt", header=T,check.names=FALSE)
factor_w <- read.table("factor_w.txt", header=T,check.names=FALSE)
# Mortality: Heligman-Pollard model: parameters, migrants
par_mttf <- read.table("par_mt4_F.txt", header=T,check.names=FALSE)
par_wttf <- read.table("par_wt4_F.txt", header=T,check.names=FALSE)
# Mortality: Heligman-Pollard model: factors, migrants 
factor_fra_m <- read.table("factor_fra_m.txt", header=T,check.names=FALSE)
factor_fra_w <- read.table("factor_fra_w.txt", header=T,check.names=FALSE)
# Census data, Senegal 2002 calibrated to census 2002
dak.tot <- read.table("Dakar_sampling.csv",sep=",",header=T) 
# Census data, France 1988 (child info grom 2002) calibrated to census 1982
france.tot <- read.table("France1982.csv",sep=",",header=T) 

##---------------------------------------------------------------------------##
## B. PERFORM MICROSIMULATION
##---------------------------------------------------------------------------##
## B.1 Aux functions for Heligman-Pollard model for mortality
##---------------------------------------------------------------------------##
## Heligman-Pollard model for mortality
HP8 <-function(parS,x)
  with(parS,
       ifelse(x==0, a^((x+b)^c) + g*h^x, 
              a^((x+b)^c) + d*exp(-e*(log(x/f))^2) + g*h^x))
## Define qx = HP8/(1+HP8)
qxPred <- function(parS,x) {
  h <- HP8(parS,x)
  h/(1+h)
}
## Calculate nqx predicted by HP8 model (nqxPred(parS,x))
nqxPred <- function(parS,x){
  res <- (1 -(1-qxPred(parS,x)) * (1-qxPred(parS,x+1)) *
     (1-qxPred(parS,x+2)) * (1-qxPred(parS,x+3)) *
     (1-qxPred(parS,x+4)))
  return(res)
  } 
##---------------------------------------------------------------------------##
## B.2 Produce synthetic life-courses for natives (used in ABM as initial 
##     specification of the life courses of the individuals considered)
##---------------------------------------------------------------------------##
newlife <<- function(initPop, currenttime, endtime){
  
  # Fertility (transition) rates: between age 12 and 49 for every parity
  fert1Rates <<- function (age,calTime, duration) {   
    tmp1 <-  calTime[1]-age[1]
    tmp <- ifelse(tmp1<=1930 |tmp1>=2030 ,2020,tmp1)
    cohort <- as.character(floor(tmp / 10) * 10 - 10)    
    a <-  par[1,cohort]
    b <-  par[2,cohort]
    c <-  par[3,cohort]
    ages <- age
    rval <- a * b/c * (c/ages)^1.5 * exp(-b^2 * (c/ages + ages/c - 2))
    rates <- c(rval, rep(0,1000))           
    rate <- ifelse(age<=11| age >=50 | duration<0.75, 0, rates)
    return(rate)
  }
 
  # Fertility rates: second and higher order parity  
  fert2Rates <<- function (age,calTime, duration) {
    tmp1 <-  calTime[1]-age[1]
    tmp <- ifelse(tmp1<=1930 |tmp1>=2030 ,2020,tmp1)
    cohort <- as.character(floor(tmp / 10) * 10 - 10)    
    a <-  par2[1,cohort]
    b <-  par2[2,cohort]
    c <-  par2[3,cohort]
    ages <- age
    rval <- a * b/c * (c/ages)^1.5 * exp(-b^2 * (c/ages + ages/c - 2))
    rates <- c(rval, rep(0,1000))           
    rate <- ifelse(age<=11| age >=50| duration<0.75, 0, rates)
    return(rate)
  }
  
  # Fertility rates: third and higher order parity
  fert3Rates <<- function (age,calTime, duration) {
    tmp1 <-  calTime[1]-age[1]
    tmp <- ifelse(tmp1<=1930 |tmp1>=2030 ,2020,tmp1)
    cohort <- as.character(floor(tmp / 10) * 10 - 10)    
    a <-  par3[1,cohort]
    b <-  par3[2,cohort]
    c <-  par3[3,cohort]
    ages <- age
    rval <- a * b/c * (c/ages)^1.5 * exp(-b^2 * (c/ages + ages/c - 2))
    rates <- c(rval, rep(0,1000))       
    rate <- ifelse(age<=11| age >=50| duration<0.75, 0, rates)
    return(rate)
  }
 
  # Transition rates to first marriage for women aged 10-60
  marr.rate1_w <<- function (age, calTime, duration) {
    ages <- age
    gs <- function(x){
      0.19465 * exp(-0.174 * (x - 6.06) - 
        exp(-0.288 * (x - 6.06)))}
    GCfm <- 1.461336398 * sapply((ages - 9.716305764)/1.820908130, gs)
    rate <- GCfm
    rate[age<=9 | age>=61] <- c(0)
    return(rate)
  }
  
  # Transition rates to higher order marriage for women aged 17-67
  marr.rate2_w <<- function (age, calTime, duration) {
    ages <- age-7
    gs <- function(x) {
      0.19465 * exp(-0.174 * (x - 6.06) - 
        exp(-0.288 * (x - 6.06)))}
    GCfm <- 0.112906748 * sapply((ages - 9.901632026)/3.711969266, gs)
    rate <-GCfm 
    rate[age<=16 | age>=68] <- c(0)
    return(rate)
  }
   
  # Transition rates to first marriage for men aged 10-60
  marr.rate1_m <<- function (age, calTime, duration){
    ages <- age+3
    gs <- function(x) {
      0.19465 * exp(-0.174 * (x - 6.06) - 
        exp(-0.288 * (x - 6.06)))}
    GCfm <- 1.404111629 * sapply((ages - 15.761631959)/2.414060049, gs)
    rate <-GCfm
    rate[age<=9 | age>=61] <- c(0)
    return(rate)
  }
 
  # Transition rates to higher order marriage for men aged 17-67
  marr.rate2_m <<- function (age, calTime, duration) {
    ages <- age
    gs <- function(x) {
      0.19465 * exp(-0.174 * (x - 6.06) - 
        exp(-0.288 * (x - 6.06)))}
    GCfm <- 1.464907176 * sapply((ages - 17.805103692)/1.804457373, gs)
    rate <-GCfm 
    rate[age<=16 | age>=68] <- c(0)
    return(rate)
  }
  
  # Divorce rates
  divorceRates <<- function(age, calTime, duration){    
    rates <- c(rep(0,1000))  
    rate <- rates[age]    
    return(rate)
  }
 
  # Mortality rates for men (m) and women (w) 
  mortRates_m <<- function(age, calTime, duration){
    calTime2 <- ifelse(calTime>=2045,2045,calTime)
    period <- as.character(floor(calTime2 / 5) * 5)    
    parS <-  as.data.frame(t(par_mtt[,period]))
    names (parS) <- c("a","b","c","d","e","f","g","h")    
    x <- age
    qx <-   nqxPred(parS,x)
    rates.raw <- -log(1-qx)
    rates <- as.numeric(factor_m[2,period]*rates.raw)
    return(rates)
  }

  mortRates_w <<- function(age, calTime, duration){
    calTime2 <- ifelse(calTime>=2045,2045,calTime)
    period <- as.character(floor(calTime2 / 5) * 5)
    parS <-  as.data.frame(t(par_wtt[,period]))
    names (parS) <- c("a","b","c","d","e","f","g","h")     
    x <- age
    qx <-   nqxPred(parS,x)
    rates.raw <- -log(1-qx)
    rates <- as.numeric(factor_w[2,period]*rates.raw)
    return(rates)
  }
 
  startDate <- currenttime
  stopDate <- endtime
  simHorizon <- setSimHorizon(startDate=startDate, endDate=stopDate)
  #set.seed(123)
  maxAge <- 101
  sex <- c(10,20) # 10: male, 20: fem
  fert <- c(0,1,2,3,4,5,6,7,8,9,10,11,12,13)
  marital <- c(14,15,16) # 14: NM, 15: M, 16: D, Widowhood happens automatically through the death of the partner
  stateSpace <- expand.grid(sex=sex, fert=fert, marital=marital)
  absStates <- 'dead'
  
  fertTrMatrix <- cbind(c('20/0/15->20/1/15','20/1/15->20/2/15','20/2/15->20/3/15','20/3/15->20/4/15',
                          '20/4/15->20/5/15','20/5/15->20/6/15','20/6/15->20/7/15','20/7/15->20/8/15',
                          '20/8/15->20/9/15','20/9/15->20/10/15','20/10/15->20/11/15','20/11/15->20/12/15',
                          '20/12/15->20/13/15'), c('fert1Rates','fert2Rates', 'fert3Rates', 
                                                        'fert3Rates', 'fert3Rates', 'fert3Rates', 'fert3Rates', 
                                                        'fert3Rates', 'fert3Rates', 'fert3Rates', 'fert3Rates', 
                                                        'fert3Rates', 'fert3Rates'))
  maritalTrMatrix_f <- cbind(c('20/14->20/15','20/15->20/16','20/16->20/15'),
                           c('marr.rate1_w','divorceRates','marr.rate2_w'))
  maritalTrMatrix_m <- cbind(c('10/14->10/15','10/16->10/15'),
                             c('marr.rate1_m','marr.rate2_m'))
  
  allTransitions <- rbind(fertTrMatrix, maritalTrMatrix_f, maritalTrMatrix_m)
  absTransitions <- rbind(c("20/dead","mortRates_w"), c("10/dead","mortRates_m"))
  transitionMatrix <- buildTransitionMatrix(allTransitions=allTransitions,
                                            absTransitions=absTransitions,stateSpace=stateSpace)
  
  # Define transitions triggering a birth event
  fertTr <- c("20/0/15->20/1/15", "20/2/15->20/3/15", "20/4/15->20/5/15","20/6/15->20/7/15","20/8/15->20/9/15",
    "20/10/15->20/11/15","20/12/15->20/13/15","20/1/15->20/2/15","20/3/15->20/4/15","20/5/15->20/6/15",
    "20/7/15->20/8/15","20/9/15->20/10/15","20/11/15->20/12/15","20/13/15->20/13/15" )
  
  # Defining initial states for newborns and related occurrence probabilities
  initStates <- rbind(c('10','0','14'), c('20','0','14'))                    
  initStatesProb <- c(0.5,0.5) # Equal amounts of boys and girls 

  pop <- micSim(initPop=initPop, transitionMatrix=transitionMatrix, 
                absStates=absStates, initStates=initStates, initStatesProb=initStatesProb,
                maxAge=maxAge, simHorizon=simHorizon, fertTr=fertTr)
  
  if (class(pop)!= 'numeric')
    {pop$ID<-as.numeric(pop$ID)}
  return(pop) 
}

##---------------------------------------------------------------------------##
## B.3 Produce synthetic life-courses for natives (with higher mortality for 
##     those who have too little consumption)
##---------------------------------------------------------------------------##
newlifeMort <<- function(initPop, currenttime, endtime){
  
  # Fertility (transition) rates: between age 12 and 49 for every parity  
  fert1Rates <<- function (age,calTime, duration) {    
    tmp1 <-  calTime[1]-age[1]
    tmp <- ifelse(tmp1<=1930 |tmp1>=2030 ,2020,tmp1)
    cohort <- as.character(floor(tmp / 10) * 10 - 10)    
    a <-  par[1,cohort]
    b <-  par[2,cohort]
    c <-  par[3,cohort]
    ages <- age
    rval <- a * b/c * (c/ages)^1.5 * 
      exp(-b^2 * (c/ages + ages/c - 2))
    rates <- c(rval, rep(0,1000))       
    rate <- ifelse(age<=11| age >=50| duration<0.75, 0, rates)
    return(rate)
  }
  
  # Fertility rates: second and higher order parity  
  fert2Rates <<- function (age,calTime, duration) {
    tmp1 <-  calTime[1]-age[1]
    tmp <- ifelse(tmp1<=1930 |tmp1>=2030 ,2020,tmp1)
    cohort <- as.character(floor(tmp / 10) * 10 - 10)    
    a <-  par2[1,cohort]
    b <-  par2[2,cohort]
    c <-  par2[3,cohort]
    ages <- age
    rval <- a * b/c * (c/ages)^1.5 * 
      exp(-b^2 * (c/ages + ages/c - 2))
    rates <- c(rval, rep(0,1000))       
    rate <- ifelse(age<=11| age >=50| duration<0.75, 0, rates)
    return(rate)
  }
  
  # Fertility rates: third and higher order parity
  fert3Rates <<- function (age,calTime, duration) {
    tmp1 <-  calTime[1]-age[1]
    tmp <- ifelse(tmp1<=1930 |tmp1>=2030 ,2020,tmp1)
    cohort <- as.character(floor(tmp / 10) * 10 - 10)    
    a <-  par3[1,cohort]
    b <-  par3[2,cohort]
    c <-  par3[3,cohort]
    ages <- age
    rval <- a * b/c * (c/ages)^1.5 * 
      exp(-b^2 * (c/ages + ages/c - 2))
    rates <- c(rval, rep(0,1000))           
    rate <- ifelse(age<=11| age >=50| duration<0.75, 0, rates)
    return(rate)
  }
 
  # Transition rates to first marriage for women aged 10-60
  marr.rate1_w <<- function (age, calTime, duration) {
    ages <- age
    gs <- function(x) {
      0.19465 * exp(-0.174 * (x - 6.06) - 
        exp(-0.288 * (x - 6.06)))}
    GCfm <- 1.461336398 * sapply((ages - 9.716305764)/1.820908130, gs)
    rate <- GCfm
    rate[age<=9 | age>=61] <- c(0)
    return(rate)
  }
  
  # Transition rates to higher order marriage for women aged 17-67
  marr.rate2_w <<- function (age, calTime, duration) {
    ages <- age-7
    gs <- function(x) {
      0.19465 * exp(-0.174 * (x - 6.06) - 
        exp(-0.288 * (x - 6.06)))
    }
    GCfm <- 0.112906748 * sapply((ages - 9.901632026)/3.711969266, gs)
    rate <-GCfm 
    rate[age<=16 | age>=68] <- c(0)
    return(rate)
  }
    
  # Transition rates to first marriage for men aged 10-60
  marr.rate1_m <<- function (age, calTime, duration) {
    ages <- age+3
    gs <- function(x) {
      0.19465 * exp(-0.174 * (x - 6.06) - 
        exp(-0.288 * (x - 6.06)))}
    GCfm <- 1.404111629 * sapply((ages - 15.761631959)/2.414060049, gs)
    rate <- GCfm
    rate[age<=9 | age>=61] <- c(0)
    return(rate)
  }
    
  # Transition rates to higher order marriage for men aged 17-67
  marr.rate2_m <<- function (age, calTime, duration) {
    ages <- age
    gs <- function(x) {
      0.19465 * exp(-0.174 * (x - 6.06) - 
        exp(-0.288 * (x - 6.06)))}
    GCfm <- 1.464907176 * sapply((ages - 17.805103692)/1.804457373, gs)
    rate <-GCfm 
    rate[age<=16 | age>=68] <- c(0)
    return(rate)
  }
  
  # Divorce rates
  divorceRates <<- function(age, calTime, duration){    
    rates <- c(rep(0,1000))  
    rate <- rates[age]    
    return(rate)
  }
  
  # Mortality rates for men 
  mortRates_m <<- function(age, calTime, duration){
    calTime2 <- ifelse(calTime>=2045,2045,calTime)
    period <- as.character(floor(calTime2 / 5) * 5)    
    parS <-  as.data.frame(t(par_mtt[,period]))
    names (parS) <- c("a","b","c","d","e","f","g","h")    
    x <- age
    qx <-   nqxPred(parS,x)
    rates.raw <- -log(1-qx)
    rates <- as.numeric(factor_m[1,period]*rates.raw)
    return(rates)
  }
  
   # Mortality rates for women 
  mortRates_w <<- function(age, calTime, duration){
    calTime2 <- ifelse(calTime>=2045,2045,calTime)
    period <- as.character(floor(calTime2 / 5) * 5)    
    parS <-  as.data.frame(t(par_wtt[,period]))
    names (parS) <- c("a","b","c","d","e","f","g","h")    
    x <- age
    qx <-   nqxPred(parS,x)
    rates.raw <- -log(1-qx)
    rates <- as.numeric(factor_w[1,period]*rates.raw)
    return(rates)
  }
   
  startDate <- currenttime
  stopDate <- endtime
  simHorizon <- setSimHorizon(startDate=startDate, endDate=stopDate)
  #set.seed(123)
  maxAge <- 101
  sex <- c(10,20) # 10: male, 20: fem
  fert <- c(0,1,2,3,4,5,6,7,8,9,10,11,12,13)
  marital <- c(14,15,16) # 14: NM, 15: M, 16: D, Widowhood happens automatically through the death of the partner
  stateSpace <- expand.grid(sex=sex, fert=fert, marital=marital)
  absStates <- 'dead'
  
  fertTrMatrix <- cbind(c('20/0/15->20/1/15','20/1/15->20/2/15','20/2/15->20/3/15','20/3/15->20/4/15',
                          '20/4/15->20/5/15','20/5/15->20/6/15','20/6/15->20/7/15','20/7/15->20/8/15',
                          '20/8/15->20/9/15','20/9/15->20/10/15','20/10/15->20/11/15','20/11/15->20/12/15',
                          '20/12/15->20/13/15'), c('fert1Rates','fert2Rates', 'fert3Rates', 
                                             'fert3Rates', 'fert3Rates', 'fert3Rates', 'fert3Rates', 
                                             'fert3Rates', 'fert3Rates', 'fert3Rates', 'fert3Rates', 
                                             'fert3Rates', 'fert3Rates'))
  maritalTrMatrix_f <- cbind(c('20/14->20/15','20/15->20/16','20/16->20/15'),
                             c('marr.rate1_w','divorceRates','marr.rate2_w'))
  maritalTrMatrix_m <- cbind(c('10/14->10/15','10/16->10/15'),
                             c('marr.rate1_m','marr.rate2_m'))
  
  allTransitions <- rbind(fertTrMatrix, maritalTrMatrix_f, maritalTrMatrix_m)
  absTransitions <-  rbind(c("20/dead","mortRates_w"), c("10/dead","mortRates_m"))
  transitionMatrix <- buildTransitionMatrix(allTransitions=allTransitions,
                                            absTransitions=absTransitions,stateSpace=stateSpace)
  
  # Define transitions triggering a birth event
  fertTr <- c("20/0/15->20/1/15", "20/2/15->20/3/15", "20/4/15->20/5/15","20/6/15->20/7/15","20/8/15->20/9/15",
              "20/10/15->20/11/15","20/12/15->20/13/15","20/1/15->20/2/15","20/3/15->20/4/15","20/5/15->20/6/15",
              "20/7/15->20/8/15","20/9/15->20/10/15","20/11/15->20/12/15","20/13/15->20/13/15" )
  
  # Defining initial states for newborns and related occurrence probabilities
  initStates <- rbind(c('10','0','14'), c('20','0','14'))                    
  initStatesProb <- c(0.5,0.5) # Equal amounts of boys and girls 
  
  pop <- micSim(initPop=initPop, transitionMatrix=transitionMatrix, 
                 absStates=absStates, initStates=initStates, initStatesProb=initStatesProb,
                 maxAge=maxAge, simHorizon=simHorizon, fertTr=fertTr)
  
  if (class(pop)!= 'numeric')
  {pop$ID<-as.numeric(pop$ID)}
  return(pop)   
}

##---------------------------------------------------------------------------##
## B.4 Produce synthetic life-courses for migrants (used in ABM as initial 
##     specification of the life courses of the individuals considered)
##---------------------------------------------------------------------------##
newlifeMig <<- function(initPop, currenttime, endtime){
  
  # Fertility (transition) rates: between age 12 and 49 for every parity  
  fert1Rates <<- function (age,calTime, duration){
    a <-  1.71042852
    b <-  1.99999085
    c <-  29.21163626
    ages <- age
    rval <- a * b/c * (c/ages)^1.5 * exp(-b^2 * (c/ages + ages/c - 2))
    rates <- c(rval, rep(0,1000))          
    rate <- ifelse(age<=11| age >=50| duration<0.75, 0, rates)
    return(rate)
  }   
  
  # Fertility rates: second parity  
  fert2Rates <<- function (age,calTime, duration){
    a <-  1.64043468
    b <-  2.21071371
    c <-  25.2061433
    ages <- age
    rval <- a * b/c * (c/ages)^1.5 * exp(-b^2 * (c/ages + ages/c - 2))
    rates <- c(rval, rep(0,1000))           
    rate <- ifelse(age<=11| age >=50| duration<0.75, 0, rates)
    return(rate)
  }
  
  # Fertility rates: third and higher order parity
  fert3Rates <<- function (age,calTime, duration){
    a <-  1.20008448
    b <-  3.14840368
    c <-  32.13670221
    ages <- age
    rval <- a * b/c * (c/ages)^1.5 * 
      exp(-b^2 * (c/ages + ages/c - 2))
    rates <- c(rval, rep(0,1000))          
    rate <- ifelse(age<=11| age >=55| duration<0.75, 0, rates)
    return(rate)
  }
  
  # Transition rates to first marriage for Women aged 10-60
  marr.rate1_w <<- function (age, calTime, duration){
    ages <- age
    gs <- function(x) {
      0.19465 * exp(-0.174 * (x - 6.06) - 
        exp(-0.288 * (x - 6.06)))}
    GCfm <- 1.3123846 * sapply((ages - 9.7860741)/1.8229993, gs)
    rate <- GCfm
    rate[age<=9 | age>=61] <- c(0)
    return(rate)
  }
  
  # Transition rates to first marriage for men aged 10-60
  marr.rate1_m <<- function (age, calTime, duration) {
    ages <- age
    gs <- function(x) {
      0.19465 * exp(-0.174 * (x - 6.06) - 
        exp(-0.288 * (x - 6.06)))}
    GCfm <-  2.04468024 * sapply((ages - 20.41834581)/1.69296589, gs)
    rate <- GCfm   
    rate[age<=9 | age>=61] <- c(0)
    return(rate)
  }

  # Divorce rates
  divorceRates <<- function(age, calTime, duration){    
    rates <- c(rep(0,1000))  
    rate <- rates[age]    
    return(rate)
  }

  # Mortality rates for men 
  mortRates_m <<- function(age, calTime, duration){
    calTime2 <- ifelse(calTime>=2045,2045,calTime)
    period <- as.character(floor(calTime2 / 5) * 5)
    parS <-  as.data.frame(t(par_mttf[,period]))
    names (parS) <- c("a","b","c","d","e","f","g","h")    
    x <- age
    qx <-   nqxPred(parS,x)
    rates.raw <- -log(1-qx)
    rates  <- as.numeric(factor_fra_m[2,period]*rates.raw)
    return(rates)
  }

  # Mortality rates for women 
  mortRates_w <<- function(age, calTime, duration){
    calTime2 <- ifelse(calTime>=2045,2045,calTime)
    period <- as.character(floor(calTime2 / 5) * 5)
    parS <-  as.data.frame(t(par_wttf[,period]))
    names (parS) <- c("a","b","c","d","e","f","g","h")   
    x <- age
    qx <-   nqxPred(parS,x)
    rates.raw <- -log(1-qx)
    rates <-  as.numeric(factor_fra_w[2,period]*rates.raw)
    return(rates)
  }
    
  startDate <- currenttime
  stopDate <- endtime
  simHorizon <- setSimHorizon(startDate=startDate, endDate=stopDate)
  #set.seed(123)
  maxAge <- 101
  sex <- c(10,20) # 10: male, 20: fem
  fert <- c(0,1,2,3,4,5,6,7,8,9,10,11,12,13)
  marital <- c(14,15,16) # 14: NM, 15: M, 16: D, Widowhood happens automatically through the death of the partner
  stateSpace <- expand.grid(sex=sex, fert=fert, marital=marital)
  absStates <- 'dead'
  
  fertTrMatrix <- cbind(c('20/0/15->20/1/15','20/1/15->20/2/15','20/2/15->20/3/15','20/3/15->20/4/15',
                          '20/4/15->20/5/15','20/5/15->20/6/15','20/6/15->20/7/15','20/7/15->20/8/15',
                          '20/8/15->20/9/15','20/9/15->20/10/15','20/10/15->20/11/15','20/11/15->20/12/15',
                          '20/12/15->20/13/15'), c('fert1Rates','fert2Rates', 'fert3Rates', 
                                             'fert3Rates', 'fert3Rates', 'fert3Rates', 'fert3Rates', 
                                             'fert3Rates', 'fert3Rates', 'fert3Rates', 'fert3Rates', 
                                             'fert3Rates', 'fert3Rates'))
  maritalTrMatrix_f <- cbind(c('20/14->20/15','20/15->20/16'),
                             c('marr.rate1_w','divorceRates'))
  maritalTrMatrix_m <- cbind(c('10/14->10/15'),
                             c('marr.rate1_m'))
  
  allTransitions <- rbind(fertTrMatrix, maritalTrMatrix_f, maritalTrMatrix_m)
  absTransitions <-  rbind(c("20/dead","mortRates_w"), c("10/dead","mortRates_m"))
  transitionMatrix <- buildTransitionMatrix(allTransitions=allTransitions,
                                            absTransitions=absTransitions,stateSpace=stateSpace)
  
  # Define transitions triggering a birth event
  fertTr <- c("20/0/15->20/1/15", "20/2/15->20/3/15", "20/4/15->20/5/15","20/6/15->20/7/15","20/8/15->20/9/15",
              "20/10/15->20/11/15","20/12/15->20/13/15","20/1/15->20/2/15","20/3/15->20/4/15","20/5/15->20/6/15",
              "20/7/15->20/8/15","20/9/15->20/10/15","20/11/15->20/12/15","20/13/15->20/13/15" )
  
  # Defining initial states for newborns and related occurrence probabilities
  initStates <- rbind(c('10','0','14'), c('20','0','14'))                    
  initStatesProb <- c(0.5,0.5) # Equal amounts of boys and girls 
  
  pop <- micSim(initPop=initPop, transitionMatrix=transitionMatrix, 
                 absStates=absStates, initStates=initStates, initStatesProb=initStatesProb,
                 maxAge=maxAge, simHorizon=simHorizon, fertTr=fertTr
  )
  
  if (class(pop)!= 'numeric')
  {pop$ID<-as.numeric(pop$ID)}
  return(pop)   
}

##---------------------------------------------------------------------------##
## B.5 Produce synthetic life-courses for migrants (with higher mortality for 
##     those who have too little consumption)
##---------------------------------------------------------------------------##
newlifeMigMort <<- function(initPop, currenttime, endtime){
    
  # Fertility (transition) rates: between age 12 and 49 for every parity  
  fert1Rates <<- function (age,calTime, duration) {
    a <-  1.71042852
    b <-  1.99999085
    c <-  29.21163626
    ages <- age
    rval <- a * b/c * (c/ages)^1.5 * exp(-b^2 * (c/ages + ages/c - 2))
    rates <- c(rval, rep(0,1000))          
    rate <- ifelse(age<=11| age >=50| duration<0.75, 0, rates)
    return(rate)
  }
  
  # Fertility rates: second parity  
  fert2Rates <<- function (age,calTime, duration) {
    a <-  1.64043468
    b <-  2.21071371
    c <-  25.2061433
    ages <- age
    rval <- a * b/c * (c/ages)^1.5 * exp(-b^2 * (c/ages + ages/c - 2))
    rates <- c(rval, rep(0,1000))          
    rate <- ifelse(age<=11| age >=50| duration<0.75, 0, rates)
    return(rate)
  }
  
  # Fertility rates: third and higher order parity
  fert3Rates <<- function (age,calTime, duration) {
    a <-  1.20008448
    b <-  3.14840368
    c <-  32.13670221
    ages <- age
    rval <- a * b/c * (c/ages)^1.5 * 
      exp(-b^2 * (c/ages + ages/c - 2))
    rates <- c(rval, rep(0,1000))        
    rate <- ifelse(age<=11| age >=55| duration<0.75, 0, rates)
    return(rate)
  }
  
  # Transition rates to first marriage for Women aged 10-60
  marr.rate1_w <<- function (age, calTime, duration) {
    ages <- age
    gs <- function(x) {
      0.19465 * exp(-0.174 * (x - 6.06) - 
        exp(-0.288 * (x - 6.06)))}
    GCfm <- 1.3123846 * sapply((ages - 9.7860741)/1.8229993, gs)
    rate <- GCfm
    rate[age<=9 | age>=61] <- c(0)
    return(rate)
  }
    
  # Transition rates to first marriage for Men aged 10-60
  marr.rate1_m <<- function (age, calTime, duration) {
    ages <- age
    gs <- function(x) {
      0.19465 * exp(-0.174 * (x - 6.06) - 
        exp(-0.288 * (x - 6.06)))}
    GCfm <-  2.04468024 * sapply((ages - 20.41834581)/1.69296589, gs)
    rate <- GCfm    
    rate[age<=9 | age>=61] <- c(0)
    return(rate)
  }
  
  # Transition rates to higher order marriage are not modelled (i.e., transition is not possible).
  
  # Divorce rates
  divorceRates <<- function(age, calTime, duration){   
    rates <- c(rep(0,1000))  
    rate <- rates[age]    
    return(rate)
  }

  # Mortality rates for men   
  mortRates_m <<- function(age, calTime, duration){
    calTime2 <- ifelse(calTime>=2045,2045,calTime)
    period <- as.character(floor(calTime2 / 5) * 5)
    parS <-  as.data.frame(t(par_mttf[,period]))
    names (parS) <- c("a","b","c","d","e","f","g","h")    
    x <- age
    qx <-   nqxPred(parS,x)
    rates.raw <- -log(1-qx)
    rates <-  as.numeric(factor_fra_m[1,period]*rates.raw)
    return(rates)
  }

  # Mortality rates for women  
  mortRates_w <<- function(age, calTime, duration){
    calTime2 <- ifelse(calTime>=2045,2045,calTime)
    period <- as.character(floor(calTime2 / 5) * 5)
    parS <-  as.data.frame(t(par_wttf[,period]))
    names (parS) <- c("a","b","c","d","e","f","g","h")   
    x <- age
    qx <-   nqxPred(parS,x)
    rates.raw <- -log(1-qx)
    rates <-   as.numeric(factor_fra_w[1,period]*rates.raw)
    return(rates)
  }
  
  startDate <- currenttime
  stopDate <- endtime
  simHorizon <- setSimHorizon(startDate=startDate, endDate=stopDate)
  #set.seed(123)
  maxAge <- 101
  sex <- c(10,20) # 10: male, 20: fem
  fert <- c(0,1,2,3,4,5,6,7,8,9,10,11,12,13)
  marital <- c(14,15,16) # 14: NM, 15: M, 16: D, Widowhood happens automatically through the death of the partner
  stateSpace <- expand.grid(sex=sex, fert=fert, marital=marital)
  absStates <- 'dead'
  
  fertTrMatrix <- cbind(c('20/0/15->20/1/15','20/1/15->20/2/15','20/2/15->20/3/15','20/3/15->20/4/15',
                          '20/4/15->20/5/15','20/5/15->20/6/15','20/6/15->20/7/15','20/7/15->20/8/15',
                          '20/8/15->20/9/15','20/9/15->20/10/15','20/10/15->20/11/15','20/11/15->20/12/15',
                          '20/12/15->20/13/15'), c('fert1Rates','fert2Rates', 'fert3Rates', 
                                             'fert3Rates', 'fert3Rates', 'fert3Rates', 'fert3Rates', 
                                             'fert3Rates', 'fert3Rates', 'fert3Rates', 'fert3Rates', 
                                             'fert3Rates', 'fert3Rates'))
  maritalTrMatrix_f <- cbind(c('20/14->20/15','20/15->20/16'),
                             c('marr.rate1_w','divorceRates'))
  maritalTrMatrix_m <- cbind(c('10/14->10/15'),
                             c('marr.rate1_m'))
  
  allTransitions <- rbind(fertTrMatrix, maritalTrMatrix_f, maritalTrMatrix_m)
  absTransitions <-  rbind(c("20/dead","mortRates_w"), c("10/dead","mortRates_m"))
  transitionMatrix <- buildTransitionMatrix(allTransitions=allTransitions,
                                            absTransitions=absTransitions,stateSpace=stateSpace)
  
  # Define transitions triggering a birth event
  fertTr <- c("20/0/15->20/1/15", "20/2/15->20/3/15", "20/4/15->20/5/15","20/6/15->20/7/15","20/8/15->20/9/15",
              "20/10/15->20/11/15","20/12/15->20/13/15","20/1/15->20/2/15","20/3/15->20/4/15","20/5/15->20/6/15",
              "20/7/15->20/8/15","20/9/15->20/10/15","20/11/15->20/12/15","20/13/15->20/13/15")
  
  # Defining initial states for newborns and related occurrence probabilities
  initStates <- rbind(c('10','0','14'), c('20','0','14'))                    
  initStatesProb <- c(0.5,0.5) # Equal amounts of boys and girls 
  
  pop <- micSim(initPop=initPop, transitionMatrix=transitionMatrix, 
                 absStates=absStates, initStates=initStates, initStatesProb=initStatesProb,
                 maxAge=maxAge, simHorizon=simHorizon, fertTr=fertTr)
  
  if (class(pop)!= 'numeric')
  {pop$ID<-as.numeric(pop$ID)}
  return(pop) 
  
}

##---------------------------------------------------------------------------##
## C. TRANSFORMING R DATA TO FORMATS THAT NetLogo CAN PROCESS 
##---------------------------------------------------------------------------##
## C.1 Crucial function for transforming NetLogo dates to R dates 
##---------------------------------------------------------------------------##
# Function to transform current-time netlogo output into function input that looks 
# like this: startDate <- '01/01/2000' 
# R can only read Netlogo ticks, not Netlogo time objects. Thus, the ticks are reported. 
# The ticks are rounded to the next (larger) tick, in order to make sure that the next simulated event 
# definitely happens after the current time.
# The input to thus function has to be numeric.
# The argument `additional' is the number of years after 1970, referring to the 
# start year of the simulation. When the simulation starts in 2000, for example,
# then additional would be 30.
timetransform <<- function(CurrentTime, additional){
  # Current time has to be expressed as days since 1.1.1970.
  roundedDay <- ceiling(CurrentTime) + floor(additional * 365.25)
  currenttime <- chron(dates=roundedDay, out.format=c(dates='d/m/year'))
  months <- 1:12
  monthnames <- c("Jan", "Feb","Mar","Apr","May", "Jun", "Jul","Aug","Sep","Oct","Nov","Dec")
  monthlookup <- cbind(months,monthnames)
  # Replace the monthname by a number
  months <- 1:12
  monthnames <- c("Jan", "Feb","Mar","Apr","May", "Jun", "Jul","Aug","Sep","Oct","Nov","Dec")
  monthlookup <- cbind(months,monthnames)
  # Replace in the pop file all monthnames by numbers
  for(i in seq_len(nrow(monthlookup))){
    currenttime <- gsub(monthlookup[i,2], monthlookup[i,1],currenttime)
  }
  return(currenttime)
}

##---------------------------------------------------------------------------##
## C.2 Function to transform MicSim (R) pop-object into csv file,
##     allows reading pop object as time series in NetLogo
##---------------------------------------------------------------------------##
netlogoOutput <<- function(pop){
  
  months <- 1:12
  monthnames <- c("Jan", "Feb","Mar","Apr","May", "Jun", "Jul","Aug","Sep","Oct","Nov","Dec")
  monthlookup <- cbind(months,monthnames)
  
  # Replace in the pop file all monthnames by numbers
  for(i in seq_len(nrow(monthlookup))){
    pop$birthDate <- gsub(monthlookup[i,2], monthlookup[i,1],pop$birthDate)
  }

  for(i in seq_len(nrow(monthlookup))){
    pop$transitionTime <- gsub(monthlookup[i,2], monthlookup[i,1],pop$transitionTime)
  }

  # Change format so that date format becomes "yyyy-mm-dd"
  pop$transitionTime <- as.Date(pop$transitionTime, "%d/%m/%Y")
  pop$birthDate <- as.Date(pop$birthDate, "%d/%m/%Y")

  # Change order of columns so that TransitonTime of pop object is first column
  # For this purpose, first select the column with the TransitionTimes
  firstcolumn <- pop$transitionTime
  # Then, cut it out of the original data frame
  popohnetransitions <- subset(pop, select = -c(transitionTime) )
  # Attach again as first column
  popforlogo <- cbind(firstcolumn, popohnetransitions)

  # Now we need to create an additional column with only the new state variable, 
  # e.g. if there is a transition from 0 to 1 kids, type 1 in the new column
  # Also: type 2 instead of 2+
  popforlogo$From <- as.character(popforlogo$From)
  popforlogo$To <- as.character(popforlogo$To)
  splitpopFrom <- sapply(popforlogo$From, strsplit, "/")
  splitpopTo <- sapply(popforlogo$To, strsplit, "/")
  splitpopFrom <- do.call(rbind,splitpopFrom)
  splitpopTo <- do.call(rbind,splitpopTo)

  # Create vector to collect the non-matching components. Pay attention to NA values.
  newstate <- matrix(nrow=nrow(splitpopFrom), ncol=1)             
  for (i in seq_len(nrow(newstate))){
    if (is.na(splitpopTo[i,1])){                               # TO DO: SZ
      newstate[i,1] <- NA
    } else{
      newstate[i,1] <- setdiff(splitpopTo[i,],splitpopFrom[i,]) 
    }
  }

  # Attach the new column to popforlogo
  popforlogo <- cbind(popforlogo,newstate)
  # Delete the rows with time column NA
  popforlogo <- popforlogo[complete.cases(popforlogo[,1]),]
  
  # New column with exact time
  # Draw random hours, minutes, seconds and milliseconds
  hours <- as.character(sample(0:23,nrow(popforlogo), replace=T))
  minutes <- as.character(sample(0:59,nrow(popforlogo), replace=T))
  seconds <- as.character(sample(0:59,nrow(popforlogo), replace=T))
  milliseconds <- as.character(sample(0:999,nrow(popforlogo), replace=T))
  
  # Fill in 0s so that all hours/minutes/seconds have the same number of digits           
  time <- cbind(hours, minutes, seconds)
  for (i in seq_len(nrow(popforlogo))){                                   # TO DO: SZ
    for (j in seq_len(ncol(time))){
      if (nchar(time[i,j]) < 2) 
        time[i,j] <- paste("0",time[i,j],sep = "")  
    }  
  }

  # Do the same for milliseconds
  for (i in seq_len(nrow(popforlogo))){                            # TO DO: SZ
    if (nchar(milliseconds[i]) < 2){
      milliseconds[i] <- paste("0", "0", milliseconds[i],sep = "")
    } else {
      if (nchar(milliseconds[i]) < 3)
        milliseconds[i] <- paste("0", milliseconds[i],sep = "") 
    }
  }

  # Concatenate step by step 
  # Hours, minutes, seconds
  exacttime <- paste(time[,1], time[,2], time[,3], sep=":")
  # together with milliseconds
  completetime <- paste(exacttime,milliseconds, sep=".")
  # together with day
  datetime <- paste(popforlogo$firstcolumn, completetime, sep="T")
  # Replace first column in popforlogo with this column
  popforlogo[,1] <- datetime

  # Deal with duplicates in the time column (although it is unlikely there are any)
  if (anyDuplicated(popforlogo[,1]) > 0){
    alltimes <- popforlogo[,1]
    while (anyDuplicated(alltimes) > 0){
      duplicates <- alltimes[duplicated(alltimes)]  
      for (i in seq_len(nrow(popforlogo))) {
        if (is.element(alltimes[i],duplicates))
          str_sub(alltimes[i],-1)<-sample(0:9, 1)
      }
    }
    popforlogo[,1] <- alltimes
  }

  # Values in the column "newstate" have to be read into Netlogo variables, thus, they have to be numeric.
  # The key is the following:
  #  fert: 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13
  #  marital:13 is NM, 15 is M, 16 is D
  #  death:17

  transitionnumbers <- 0:17
  transitionnames <- c("0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", 
                       "16", "dead")
  transitionlookup <- cbind(transitionnumbers, transitionnames)
  # Replace in the newstate vector all names by numbers
  for(i in seq_len(nrow(transitionlookup))){
    popforlogo$newstate <- gsub(transitionlookup[i,2], transitionlookup[i,1],popforlogo$newstate)
  }
  popforlogo$newstate <- as.numeric(popforlogo$newstate)

  # Only pass those columns to Netlogo which we actually need: The time stamp, the ID, and the new state
  popforlogo <- subset(popforlogo, select = -c(birthDate, initState, From, To, transitionAge))
  return(popforlogo)
}

##---------------------------------------------------------------------------##
## C.3 Write popforlogo (MicSim results) into a csv file (for NetLogo)
##---------------------------------------------------------------------------##
savePopforlogo<<-function(popforlogo, filename="transitions1.csv"){  
  filepath <- paste(getwd(),filename, sep="/")   
  if (file.exists(filepath)) file.remove(filepath)  
  zz <- file(filepath,"a")  
  # In this version: only the transitions of the first cohort are written to file, because in Netlogo there are no
  # children being born yet. 
  cat(paste("time,", "ID,", "newstate",sep=""), file = zz, sep = "\n", fill = FALSE, labels = NULL, append = TRUE)
  for (i in seq_len(nrow(popforlogo))){  
      cat(popforlogo$firstcolumn[i], popforlogo$ID[i], popforlogo$newstate[i], file = zz, sep = ",")
      cat("\n", file=zz)
  }  
  close(zz)
  rm(zz)
}

##---------------------------------------------------------------------------##
## C.4 Write popforlogo (MicSim results) into a csv file (for NetLogo), 
##     initial migrant population
##---------------------------------------------------------------------------##
savePopforlogoMig<<-function(popforlogo, filename="transitions2.csv"){  
  filepath <- paste(getwd(),filename, sep="/")   
  if (file.exists(filepath)) file.remove(filepath)  
  zz <- file(filepath,"a")
  # In this version: only the transitions of the first cohort are written to file, because in Netlogo there are no
  # children being born yet. 
  cat(paste("time,", "ID,", "newstate",sep=""), file = zz, sep = "\n", fill = FALSE, labels = NULL, append = TRUE)
  for (i in seq_len(nrow(popforlogo))){  
    cat(popforlogo$firstcolumn[i], popforlogo$ID[i], popforlogo$newstate[i], file = zz, sep = ",")
    cat("\n", file=zz)
  }
  close(zz)
  rm(zz)
}

##---------------------------------------------------------------------------##
## C.5 Transform initial population (from R, micSim) that NetLogo 
##     can process it
##---------------------------------------------------------------------------##
netlogoInitpop <<- function(initPop){
  months <- 1:12
  monthnames <- c("Jan", "Feb","Mar","Apr","May", "Jun", "Jul","Aug","Sep","Oct","Nov","Dec")
  monthlookup <- cbind(months,monthnames)
  
  # First, transform dates again: Replace in the initpop file all monthnames by numbers
  for(i in seq_len(nrow(monthlookup))){
    initPop$birthDate <- gsub(monthlookup[i,2], monthlookup[i,1],initPop$birthDate)
  }
  
  # Change format so that date format becomes "yyyy-mm-dd"  
  initPop$birthDate <- as.Date(initPop$birthDate, "%d/%m/%Y")
  # Change to numeric so that Netlogo can handle it  
  initPop$birthDate <- as.numeric(initPop$birthDate)
  
  # Initstate has to be split up into the different variables. create new columns with the different contents  
  split <- sapply(as.character(initPop$initState), strsplit, "/")
  split <- do.call(rbind,split)
  sex <- split[,1]
  fert <- split[,2]
  marital <- split[,3]
  
  #Now, all values have to become numeric because Netlogo variables have to be numeric. Here is the key:
  #sex: 10 is male, 20 is female
  #fert: 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13
  #marital:14 is NM, 15 is M, 16 is D
  
  sex <- as.numeric(sex)  
  fert <- as.numeric(fert)  
  marital <- as.numeric(marital)
  
  initPopLogo <- cbind(initPop[,1:2],sex,fert,marital)
  # Rename columns so that they are exactly the same names as agent variables in Netlogo
  colnames(initPopLogo)[1] <- "id"
  colnames(initPopLogo)[2] <- "birthdate"
  
  return(initPopLogo)
}

##---------------------------------------------------------------------------##
## C.6 Transform synthetic population of children (from R, micSim) that 
##     NetLogo can process it
##---------------------------------------------------------------------------##
# Argument `popShort' is a data file only containing the original synth. pop minus the initial population 
# (i.e. only children)
initChildren <<- function(popShort){   
  
  # Drop unnecessary columns
  initChildren <- popShort[1:3]
  # Retain only one observation per person, since here we are not interested in the transitions, 
  # just the initial status (birthdate and gender)
  initChildren <- unique(initChildren)
  
  # The remaining steps are essentially as above
  months <- 1:12
  monthnames <- c("Jan", "Feb","Mar","Apr","May", "Jun", "Jul","Aug","Sep","Oct","Nov","Dec")
  monthlookup <- cbind(months,monthnames)
  # First, transform dates again: Replace all monthnames by numbers
  for(i in seq_len(nrow(monthlookup))){
    initChildren$birthDate <- gsub(monthlookup[i,2], monthlookup[i,1],initChildren$birthDate)
  }
  # Change format so that date format becomes "yyyy-mm-dd"  
  initChildren$birthDate <- as.Date(initChildren$birthDate, "%d/%m/%Y")
  # Change to numeric so that Netlogo can handle it  
  initChildren$birthDate <- as.numeric(initChildren$birthDate)
  
  # Initstate has to be split up into the different variables. create new columns with the different contents 
  split <- sapply(initChildren$initState, strsplit, "/")
  split <- do.call(rbind,split)
  sex <- split[,1]
  sex <- as.numeric(sex)
  
  initChildrenLogo <- cbind(initChildren[,1:2],sex)
  # Rename columns so that they are exactly the same names as agent variables in Netlogo
  colnames(initChildrenLogo)[1] <- "id"
  colnames(initChildrenLogo)[2] <- "birthdate"

  return(initChildrenLogo)  
}

##---------------------------------------------------------------------------##
## D. FURTHER FUNCTIONS USED BY NETLOGO WHILE RUNNING SIMULATION
##---------------------------------------------------------------------------##
## D.1 Generate random income value
##---------------------------------------------------------------------------##
lognormalrandom <- function(mu, gini){
  normalsd <- gini * mu * (pi)^(1/2)
  stdSquaredLog <- log(1+((normalsd^2)/(mu ^ 2)))
  muLog<-log(mu) - (1/2) * stdSquaredLog
  # For a single value
  randomIncome <- rlnorm(1,mean=muLog, sd= stdSquaredLog^(1/2))
  return(randomIncome)
}

##---------------------------------------------------------------------------##
## D.2 Function to create for one single individual an `initPop' object for 
##    `micSim'
##---------------------------------------------------------------------------##
initialstatus <- function(ID, birthdate, initState){
  birthDate <- chron(dates=birthdate, out.format=c(dates='d/m/year'))
  initPop <- data.frame(ID, birthDate, initState, stringsAsFactors=FALSE)  
  return (initPop)
}

##---------------------------------------------------------------------------##
## D.3 Function to transform NetLogo `time object' into ticks (in R: days)
##---------------------------------------------------------------------------##
# Function to transform current-time NetLogo output into function input that looks 
# like this: startDate <- '01/01/2000' (function input is numeric). 
# R can only read Netlogo ticks, not Netlogo time objects. Thus, the ticks are reported. 
# The ticks are rounded to the next(larger) tick, in order to make sure that the next 
# simulated event definitely happens after the current time.
# The parameter `additional' is the number of years after 1970, referring to the start year
# of the simulation. When the simulation starts in 2000, for example, then additional would be 30.
timetransform <- function(CurrentTime, additional){
# Current time has to be expressed as days since 1.1.1970.
  roundedDay<-ceiling(CurrentTime) + floor(additional * 365.25)
  currenttime<-chron(dates=roundedDay, out.format=c(dates='d/m/year'))
  months<-1:12
  monthnames<-c("Jan", "Feb","Mar","Apr","May", "Jun", "Jul","Aug","Sep","Oct","Nov","Dec")
  monthlookup<-cbind(months,monthnames)
  # Replace the monthname by a number
  months<-1:12
  monthnames<-c("Jan", "Feb","Mar","Apr","May", "Jun", "Jul","Aug","Sep","Oct","Nov","Dec")
  monthlookup<-cbind(months,monthnames)
  # Replace in the pop file all monthnames by numbers
  for(i in seq_len(nrow(monthlookup))){
    currenttime<-gsub(monthlookup[i,2], monthlookup[i,1],currenttime)
  }
  return(currenttime)
}

##---------------------------------------------------------------------------##
## E. SAMPLING FROM CENSUS
##---------------------------------------------------------------------------##
## E.1 Generate random day and month for birth date    
##---------------------------------------------------------------------------##
latemail <- function(N, year,st="2012-01-01", et="2012-12-31") {
  st <- as.Date(st)
  et <- as.Date(et)
  dt <- as.numeric(difftime(et,st))
  ev <- runif(N, 0, dt)
  rt <- year + ev
}

##---------------------------------------------------------------------------##
## E.2 Sampling of men and women in Dakar (calibrated to census 1988)  
##---------------------------------------------------------------------------##
## Here: The number of wives and husbands is equal.
## NOTE: Currently, funtion only works for equal numbers (N).
init_pop_f <- function(N) {
  Men <- dak.tot[dak.tot$sex=="Male",]
  Women<- dak.tot[dak.tot$sex=="Female",]
  Marr.Women <- Women[Women$sex=="Female" & Women$marst=="Married/in union",]
  Single.Women <- Women[Women$sex=="Female" & Women$marst!="Married/in union",]
  Male <- sample(Men$id,N/2, replace = FALSE, prob = Men$postWeights)
  Men2 <- Men[Men$id %in% Male, ] 
  table <- table(Men2$marst)
  Marr.Female <- sample(Marr.Women$id, table[1], replace = FALSE, prob = Marr.Women$postWeights)
  Single.Female <- sample(Single.Women$id, N/2-table[1], replace = FALSE, prob = Single.Women$postWeights)
  Female1 <- Women[Women$id %in% Marr.Female, ] 
  Female2  <- Women[Women$id %in%Single.Female, ] 
  Female <- rbind(Female1 ,Female2)
  Total <-  rbind(Men2 ,Female)
  table(Total$marst)
  Total$sex2 <- ifelse(Total$sex=="Male", 10,20)
  Total$marst2 <- recode(Total$marst, 
    "'Single/never married'=14;'Widowed'=14; 'Unknown/missing'=14;'Married/in union'=15; 'Separated/divorced/spouse absent'=16;", 
    as.factor.result=FALSE)
  Total$chborn1[is.na(Total$chborn1)] <- 0
  Total$birthyr2 <- round(1981 - Total$age)
  as.character(Total$birthyr2)
  s <- as.Date(paste(Total$birthyr2, "Jan","01"), format="%Y %b %d")
  s2 <- as.Date(s,format = "%Y-%m-%d")
  Total$birth.date <- latemail(N, s2)
  posix.date <- as.POSIXct(Total$birth.date, origin = "1970-01-01")
  result <- as.Date(posix.date, format = "%Y-%m-%d %Z",out.format ="%m/%d/%y")
  birthDate<-chron(dates=as.numeric(result) ,out.format=c(dates='d/m/year'))   ###right format of the date
  Total$initState <-paste(Total$sex2,Total$chborn1,Total$marst2 ,  sep='/')
  initPop <- data.frame(ID=1:N, birthDate=birthDate, initState=Total$initState,
                        stringsAsFactors=FALSE)
  return(initPop)
}

##---------------------------------------------------------------------------##
## E.3 Sampling of men and women in France (calibrated to census 1982)  
##---------------------------------------------------------------------------##
## Here: The number of wives and husbands is equal.
## NOTE: Currently, funtion only works for equal numbers (N).
init_pop_f_mig <- function(N) {
  Men <- france.tot[france.tot$sex=="Male",]
  Women<- france.tot[france.tot$sex=="Female",]
  Marr.Women <- Women[Women$sex=="Female" & Women$marst=="M",]
  Single.Women <- Women[Women$sex=="Female" & Women$marst!="M",]
  Male <- sample(Men$ID,N/2, replace = FALSE, prob = Men$postWeights2)
  Men2 <- Men[Men$ID %in% Male, ] 
  table <- table(Men2$marst)
  Marr.Female <- sample(Marr.Women$ID, table[2], replace = FALSE, prob = Marr.Women$postWeights2)
  Single.Female <- sample(Single.Women$ID, N/2-table[2], replace = FALSE, prob = Single.Women$postWeights2)
  Female1 <- Women[Women$ID %in% Marr.Female, ] 
  Female2  <- Women[Women$ID %in%Single.Female, ] 
  Female <- rbind(Female1 ,Female2)
  Total <-  rbind(Men2 ,Female)
  table(Total$marst)
  Total$sex2 <- ifelse(Total$sex=="Male", 10,20)
  Total$marst2 <- recode(Total$marst, "'S'=14;'W'=14;'M'=15; 'D'=16;", as.factor.result=FALSE)
  Total$chborn1[is.na(Total$chborn1)] <- 0
  Total$birthyr2 <- round(1981 - Total$age)
  as.character(Total$birthyr2)
  s <- as.Date(paste(Total$birthyr2, "Jan","01"), format="%Y %b %d")
  s2 <- as.Date(s,format = "%Y-%m-%d")
  Total$birth.date <- latemail(N, s2)
  posix.date <- as.POSIXct(Total$birth.date, origin = "1970-01-01")
  result <- as.Date(posix.date, format = "%Y-%m-%d %Z",out.format ="%m/%d/%y")
  birthDate<-chron(dates=as.numeric(result) ,out.format=c(dates='d/m/year'))   ###right format of the date
  Total$initState <-paste(Total$sex2,Total$chborn1,Total$marst2 ,  sep='/')
  initPop <- data.frame(ID=1:N, birthDate=birthDate, initState=Total$initState,
                        stringsAsFactors=FALSE)
  return(initPop)
}